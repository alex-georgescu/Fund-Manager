﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FundManager.Models;

namespace FundManager.UnitTesting
{
    [TestClass]
    public class StockManager_Tests
    {

        [TestMethod]
        public void AddStock_EmptyPriceTest()
        {
            StockManager stockManager = new StockManager();
            Assert.IsFalse(stockManager.AddStock(StockType.Bond, "", "test123"));
        }

        [TestMethod]
        public void AddStock_EmptyQuantityTest()
        {
            StockManager stockManager = new StockManager();
            Assert.IsFalse(stockManager.AddStock(StockType.Bond, "test123", ""));
        }


        [TestMethod]
        public void AddStock_StringPriceTest()
        {
            StockManager stockManager = new StockManager();
            Assert.IsFalse(stockManager.AddStock(StockType.Bond, "test123", "123"));
        }


        [TestMethod]
        public void AddStock_StringQuantityTest()
        {
            StockManager stockManager = new StockManager();
            Assert.IsFalse(stockManager.AddStock(StockType.Bond, "123", "test123"));
        }


        [TestMethod]
        public void AddStock_NegativePriceTest()
        {
            StockManager stockManager = new StockManager();
            Assert.IsFalse(stockManager.AddStock(StockType.Bond, "-123", "123"));
        }

        [TestMethod]
        public void AddStock_NegativeQuantityTest()
        {
            StockManager stockManager = new StockManager();
            Assert.IsFalse(stockManager.AddStock(StockType.Bond, "123", "-123"));
        }


        [TestMethod]
        public void AddStock_PositiveDoublePriceTest()
        {
            StockManager stockManager = new StockManager();
            Assert.IsTrue(stockManager.AddStock(StockType.Bond, "12.3756", "123"));
        }


        [TestMethod]
        public void AddStock_PositiveUlongQuantityTest()
        {
            StockManager stockManager = new StockManager();
            Assert.IsTrue(stockManager.AddStock(StockType.Bond, "1221", "123"));
        }

        [TestMethod]
        public void AddStock_PositiveDoubleQuantityTest()
        {
            StockManager stockManager = new StockManager();
            Assert.IsFalse(stockManager.AddStock(StockType.Bond, "1221", "12.3"));
        }

    }
}
