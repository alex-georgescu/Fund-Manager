﻿using FundManager.Models;
using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace FundManager.Converters
{
    public class StockInfoToSolidBrushColourConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            Stock stock = value as Stock;

            if (stock == null)
                return null;

            if (stock.MarketValue < 0 || stock.TransactionCost > stock.Tolerance)
                return new SolidColorBrush(Colors.Red);

            return new SolidColorBrush(Colors.Black);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value;
        }
    }
}
