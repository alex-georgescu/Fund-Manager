﻿using FundManager.Models;
using System.Windows;


namespace FundManager
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        #region bindable properties
        public string EnteredStockQuantity
        {
            get { return (string)GetValue(EnteredStockQuantityProperty); }
            set { SetValue(EnteredStockQuantityProperty, value); }
        }

        public static readonly DependencyProperty EnteredStockQuantityProperty =
            DependencyProperty.Register("EnteredStockQuantity", typeof(string), typeof(MainWindow), new PropertyMetadata(string.Empty));


        public string EnteredStockPrice
        {
            get { return (string)GetValue(EnteredStockPriceProperty); }
            set { SetValue(EnteredStockPriceProperty, value); }
        }

        public static readonly DependencyProperty EnteredStockPriceProperty =
            DependencyProperty.Register("EnteredStockPrice", typeof(string), typeof(MainWindow), new PropertyMetadata(string.Empty));


        public StockManager StockManagerModel
        {
            get { return (StockManager)GetValue(StockManagerModelProperty); }
            set { SetValue(StockManagerModelProperty, value); }
        }

        public static readonly DependencyProperty StockManagerModelProperty = 
            DependencyProperty.Register("StockManagerModel", typeof(StockManager), typeof(MainWindow), new PropertyMetadata(null));
        #endregion


        public MainWindow()
        {
            InitializeComponent();
        }


        #region methods
        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            StockManagerModel = new StockManager();
        }


        private void AddEquity_Click(object sender, RoutedEventArgs e)
        {
            StockManagerModel.AddStock(StockType.Equity, EnteredStockPrice, EnteredStockQuantity);
        }


        private void AddBond_Click(object sender, RoutedEventArgs e)
        {
            StockManagerModel.AddStock(StockType.Bond, EnteredStockPrice, EnteredStockQuantity);
        }
        #endregion
    }
}
