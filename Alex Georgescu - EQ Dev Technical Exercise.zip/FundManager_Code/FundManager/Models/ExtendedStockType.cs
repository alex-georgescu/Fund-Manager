﻿
namespace FundManager.Models
{
    public enum ExtendedStockType
    {
        Equity = 1,
        Bond = 2,
        All = 3
    }
}
