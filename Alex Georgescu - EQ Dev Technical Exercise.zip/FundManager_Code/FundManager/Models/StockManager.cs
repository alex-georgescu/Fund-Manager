﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;

namespace FundManager.Models
{
    public class StockManager : INotifyPropertyChanged
    {
        #region INotifyPropertyChanged interface implementation

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(name));
            }
        }

        #endregion


        #region bindable properties
        private ObservableCollection<Stock> _stocks = null;
        public ObservableCollection<Stock> Stocks
        {
            get
            {
                return _stocks;
            }

            private set
            {
                if (_stocks == null || _stocks != value)
                {
                    _stocks = value;
                    OnPropertyChanged(nameof(Stocks));
                }
            }
        }


        private ObservableCollection<StockTypeSummary> _stockSummary = null;
        public ObservableCollection<StockTypeSummary> StockSummary
        {
            get
            {
                return _stockSummary;
            }

            private set
            {
                if (_stockSummary == null || _stockSummary != value)
                {
                    _stockSummary = value;
                    OnPropertyChanged(nameof(Stocks));
                }
            }
        }

        #endregion


        public StockManager()
        {
            Stocks = new ObservableCollection<Stock>();
            StockSummary = new ObservableCollection<StockTypeSummary>();
        }


        #region methods

        public bool AddStock(StockType stockType, string stringPrice, string stringQuantity)
        {
            if (string.IsNullOrWhiteSpace(stringPrice) || string.IsNullOrWhiteSpace(stringQuantity))
            {
                MessageBox.Show("Please fill in all the required fields (quantity and price) before continuing!");
                return false;
            }

            double stockPrice = 0;
            ulong stockQuantity = 0;

            if (!double.TryParse(stringPrice, out stockPrice) || !ulong.TryParse(stringQuantity, out stockQuantity) || stockPrice <= 0)
            {
                MessageBox.Show("Please use only (positive) numbers for completing the required fields (quantity and price)!");
                return false;
            }

            return AddStock(stockType, ref stockPrice, ref stockQuantity);
        }


        private bool AddStock(StockType stockType, ref double stockPrice, ref ulong stockQuantity)
        {
            if (stockPrice <= 0)
            {
                MessageBox.Show("Please specify a valid (positive) price!");
                return false;
            }

            AddStock(new Stock()
            {
                Type = stockType,
                Price = stockPrice,
                Quantity = stockQuantity
            });

            return true;
        }


        private void AddStock(Stock newStock)
        {
            // summary info for the right stock type
            ExtendedStockType extStockType = (ExtendedStockType)Enum.Parse(typeof(ExtendedStockType), newStock.Type.ToString());
            StockTypeSummary stockTypeInfo = StockSummary.FirstOrDefault(category => category.Type == extStockType);
            if (stockTypeInfo == null)
            {
                stockTypeInfo = new StockTypeSummary(extStockType);
                StockSummary.Insert(0, stockTypeInfo);
            }
            
            // keep track for "all" stock types
            var allStockTypeInfo = StockSummary.FirstOrDefault(category => category.Type == ExtendedStockType.All);
            if (allStockTypeInfo == null)
            {
                allStockTypeInfo = new StockTypeSummary(ExtendedStockType.All);
                StockSummary.Add(allStockTypeInfo);
            }
                        
            // update the summary info for the proper stock category
            stockTypeInfo.UpdateCountAndMarketValue(ref newStock);
            newStock.Name = $"{newStock.Type}{stockTypeInfo.TotalNumber}";

            // update the summary info for the generic stock category
            allStockTypeInfo.UpdateCountAndMarketValue(ref newStock);

            // add stock to the actual stock collection
            Stocks.Add(newStock);

            // adjust / calculate StockWeight per stock and per stock category
            AdjustStockWeights(ref allStockTypeInfo);
        }


        private void AdjustStockWeights(ref StockTypeSummary allStockSummary)
        {
            // reset StockWeight for each StockTypeSummary
            foreach (var stockTypeSummary in StockSummary)
            {
                stockTypeSummary.TotalStockWeight = 0;
            }

            foreach (var stock in Stocks)
            {
                stock.StockWeight = stock.MarketValue / allStockSummary.TotalMarketValue * 100;

                // update StockWeight for the generic summary info
                allStockSummary.TotalStockWeight += stock.StockWeight;

                // update StockWeight for the corresponding summary info
                ExtendedStockType extStockType = (ExtendedStockType)Enum.Parse(typeof(ExtendedStockType), stock.Type.ToString());
                StockTypeSummary stockTypeInfo = StockSummary.FirstOrDefault(category => category.Type == extStockType);
                if (stockTypeInfo != null)
                {
                    stockTypeInfo.TotalStockWeight += stock.StockWeight;
                }
            }
        }

        #endregion
    }
}
