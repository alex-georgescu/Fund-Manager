﻿using System.ComponentModel;

namespace FundManager.Models
{
    public class Stock : INotifyPropertyChanged
    {
        #region INotifyPropertyChanged interface implementation

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(name));
            }
        }

        #endregion


        private double _price;
        public double Price
        {
            get
            {
                return _price;
            }

            set
            {
                if (_price != value)
                {
                    _price = value;
                    OnPropertyChanged(nameof(Price));
                    OnPropertyChanged(nameof(MarketValue));
                }
            }
        }


        private ulong _quantity;
        public ulong Quantity
        {
            get
            {
                return _quantity;
            }

            set
            {
                if (_quantity != value)
                {
                    _quantity = value;
                    OnPropertyChanged(nameof(Quantity));
                    OnPropertyChanged(nameof(MarketValue));
                }
            }
        }


        private StockType _type;
        public StockType Type
        {
            get
            {
                return _type;
            }

            set
            {
                if (_type != value)
                {
                    _type = value;
                    OnPropertyChanged(nameof(Type));
                    OnPropertyChanged(nameof(TransactionCost));
                    OnPropertyChanged(nameof(Tolerance));
                }
            }
        }


        private string _name = string.Empty;
        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                if (_name != value)
                {
                    _name = value;
                    OnPropertyChanged(nameof(Name));
                }
            }
        }

        public double MarketValue
        {
            get
            {
                return Price * Quantity;
            }
        }


        private double _stockWeight;
        public double StockWeight
        {
            get
            {
                return _stockWeight;
            }

            set
            {
                if (_stockWeight != value)
                {
                    _stockWeight = value;
                    OnPropertyChanged(nameof(StockWeight));
                }
            }
        }


        public double TransactionCost
        {
            get
            {
                switch (Type)
                {
                    case StockType.Equity:
                        return MarketValue * 0.005;

                    default:
                        return MarketValue * 0.02;
                }
            }
        }


        public uint Tolerance
        {
            get
            {
                switch (Type)
                {
                    case StockType.Equity:
                        return 200000;

                    default:
                        return 100000;
                }
            }
        }
        
    }

}
