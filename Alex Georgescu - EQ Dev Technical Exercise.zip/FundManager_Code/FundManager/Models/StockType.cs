﻿namespace FundManager.Models
{
    public enum StockType
    {
        Equity = 1,
        Bond = 2
    }
}
