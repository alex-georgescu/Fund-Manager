﻿using System.ComponentModel;


namespace FundManager.Models
{
    public class StockTypeSummary : INotifyPropertyChanged
    {
        #region INotifyPropertyChanged interface implementation

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(name));
            }
        }

        #endregion


        #region bindable properties
        private ulong _totalNumber;
        public ulong TotalNumber
        {
            get { return _totalNumber; }
            set { _totalNumber = value; OnPropertyChanged(nameof(TotalNumber)); }
        }


        private double _totalStockWeight;
        public double TotalStockWeight
        {
            get { return _totalStockWeight; }
            set { _totalStockWeight = value; OnPropertyChanged(nameof(TotalStockWeight)); }
        }


        private double _totalMarketValue;
        public double TotalMarketValue
        {
            get { return _totalMarketValue; }
            set { _totalMarketValue = value; OnPropertyChanged(nameof(TotalMarketValue)); }
        }


        public ExtendedStockType Type { get; private set; }
        #endregion


        public StockTypeSummary(ExtendedStockType type)
        {
            Type = type;
        }


        #region methods
        public void UpdateCountAndMarketValue(ref Stock newStock)
        {
            TotalNumber ++;            
            TotalMarketValue += newStock.MarketValue;
        }

        #endregion
    }
}
